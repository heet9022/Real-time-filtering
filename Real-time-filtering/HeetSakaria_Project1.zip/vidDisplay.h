#pragma once
class vidDisplay
{
};
